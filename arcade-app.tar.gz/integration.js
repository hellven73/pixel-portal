import {renovate} from './renovation.js';
// Add the Portal library to the complete Arcade application, sharing its launcher and layout.
const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
const button=(text,fn,cls='')=>{const b=el('button',text,cls);b.type='button';b.onclick=fn;return b;};
const playGroup=document.querySelector('#side-nav [data-section=big]')?.parentElement;
const libraryNav=button('All games',()=>showSection('all'),'side-link');libraryNav.dataset.section='all';playGroup?.append(libraryNav);
const page=el('section',undefined,'clean-ports');page.id='webports-page';page.hidden=true;
const heading=el('div',undefined,'tool-heading'),copy=el('div');copy.append(el('span','THE WEBPORT COLLECTION','eyebrow'),el('h1','Webported games'),el('p','20 popular games. One port per title.'));heading.append(copy);
const search=el('input');search.type='search';search.placeholder='Find a webported game…';search.setAttribute('aria-label','Search webported games');
const grid=el('div',undefined,'ports-grid'),status=el('p','Loading ports…','tool-note');page.append(heading,search,grid,status);document.querySelector('main').insertBefore(page,document.querySelector('main>footer'));
const portsNav=button('Webported games',()=>showSection('webports'),'side-link');portsNav.dataset.section='webports';playGroup?.append(portsNav);
let ports=[];function drawPorts(){const q=search.value.toLowerCase();grid.replaceChildren(...ports.filter(p=>p.name.toLowerCase().includes(q)).map(p=>{const b=button('',()=>openGame({id:p.id,name:p.name,cat:'Webported Games',size:'big',embed:p.url,external:true,help:'External webport · '+p.host+(p.requirements?' · '+p.requirements:'')},true),'ports-card');b.setAttribute('aria-label','Play '+p.name);const art=el('span',p.name.split(/\s+/).slice(0,2).map(s=>s[0]).join(''),'ports-card-art'),info=el('span',undefined,'ports-card-copy');info.append(el('strong',p.name),el('small',p.requirements||p.host+' ↗'));b.append(art,info);return b;}));}
search.oninput=drawPorts;
fetch('webports.json?v=4').then(r=>r.json()).then(data=>{ports=data.games;drawPorts();status.textContent='Ports run on their original hosts. Large games may need a desktop browser; provider availability can change.';}).catch(()=>status.textContent='The port catalogue could not load. Please refresh.');
const previous=showSection;showSection=function(next){previous(next==='webports'?'home':next);page.hidden=next!=='webports';if(next==='webports'){document.querySelector('#home-page').hidden=true;section=next;document.body.dataset.section=next;history.replaceState(null,'','#webports');document.querySelector('.compact-breadcrumb strong').textContent='Webported games';document.querySelectorAll('.side-link').forEach(b=>b.classList.toggle('active',b.dataset.section===next));}else{libraryNav.classList.toggle('active',next==='all');if(next==='all')document.querySelector('#side-nav [data-section=big]')?.classList.add('active');}};
const pager=el('div',undefined,'clean-library-pager'),label=el('span');const prev=button('← Previous',()=>{window.pixelLibraryPage--;render();document.querySelector('#library-page').scrollIntoView({block:'start'});}),next=button('Next →',()=>{window.pixelLibraryPage++;render();document.querySelector('#library-page').scrollIntoView({block:'start'});});pager.append(prev,label,next);document.querySelector('#library-page').append(pager);
window.pixelUpdatePager=()=>{const count=Math.max(1,Math.ceil((window.pixelLibraryTotal||0)/48)),at=window.pixelLibraryPage||0;label.textContent=(at+1)+' / '+count;prev.disabled=at===0;next.disabled=at>=count-1;pager.hidden=count<=1;};
for(const selector of ['#search','#filters'])document.querySelector(selector)?.addEventListener('input',()=>{window.pixelLibraryPage=0;render();});
document.querySelector('#filters').addEventListener('click',()=>{window.pixelLibraryPage=0;render();});
fetch('/catalogue.json').then(r=>r.json()).then(data=>{const names=new Set(games.map(g=>g.name.toLowerCase())),urls=new Set(games.map(g=>g.embed||g.url));for(const g of data.games){if(names.has(g.name.toLowerCase())||urls.has(g.url))continue;games.push({id:'portal-'+g.id,name:g.name,cat:g.source||'Portal collection',size:'big',embed:g.url,external:true,cover:g.image||'',color:'#23243b',help:'From the '+g.source+' catalogue. Assets are served by the original game host.'});names.add(g.name.toLowerCase());urls.add(g.url);}render();}).catch(()=>{});
// Keep the previous Portal and its emulator, ambient music and synced notebook available.
const portal=el('a','Portal & emulator ↗','side-link');portal.href='/portal';document.querySelector('.compact-nav-bottom')?.prepend(portal);
fetch('/arcade-api/status').then(r=>r.json()).then(data=>{if(data.ephemeralStorage){const note=el('div','Preview hosting · Accounts and chat can reset when the server restarts.','clean-status');note.setAttribute('role','status');document.querySelector('main').prepend(note);}}).catch(()=>{});
if(window.pixelRequestedSection==='webports')showSection('webports');
// One remembered entrance, with replay and full guided setup still in More.
let seen=true;try{seen=localStorage.getItem('px-intro-seen-v3')==='1';}catch{}
if(!seen&&!window.pixelRequestedSection&&!new URLSearchParams(location.search).has('play')&&!window.pixelStudy?.active)window.pixelOnboarding?.intro();
render();
// Keep the first screen focused; every destination remains available in navigation.
const home=document.querySelector('#home-page'),essentials=home.querySelector('.home-essentials'),homeSearch=home.querySelector('#home-search-form');homeSearch.after(essentials);
const utility=home.querySelector('.home-utility-row'),fresh=home.querySelector('.new-games-strip');home.querySelector('.compact-feature').after(fresh);fresh.after(utility);
const promo=home.querySelector('.home-chat-promo');if(promo)promo.hidden=true;
const more=document.querySelector('.compact-more-panel');for(const id of ['referral-header-button','study-help-button']){const b=document.getElementById(id);if(b)more?.append(b);}
const bigNav=document.querySelector('#side-nav [data-section=big]');if(bigNav){bigNav.querySelector('.compact-label').textContent='Game library';bigNav.onclick=()=>showSection('all');libraryNav.hidden=true;}
const portIcon=el('span',undefined,'compact-icon');portIcon.innerHTML=arcadeIcons.arcade;portsNav.prepend(portIcon);

renovate();
// Reveal only after navigation and tool modules are ready, avoiding a layout jump on entry.
document.body.classList.remove("arcade-booting");document.getElementById("arcade-boot")?.remove();
