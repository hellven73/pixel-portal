// Record new game arrivals in new-games.json; old arrivals expire automatically.
(()=>{
let initialized=false;
async function initialize(){
 if(initialized)return;initialized=true;
 const home=document.querySelector('#home-page');if(!home)return;
 try{
  const load=async path=>{const response=await fetch(path,{cache:'no-cache'});if(!response.ok)throw Error('Arrivals unavailable');return response.json();};
  const [release,mobile,ports]=await Promise.all([load(new URL('new-games.json?v=1',document.baseURI)),load(new URL('cloudmoon.json?v=1',document.baseURI)),load(new URL('../webports.json',document.baseURI))]);
  const now=Date.now(),days=Math.min(60,Math.max(1,Number(release.recentDays)||30));
  const seen=new Set(),arrivals=[];
  for(const entry of release.games){
   const date=Date.parse(entry.added+'T00:00:00Z');if(!Number.isFinite(date)||date>now||now-date>=days*86400000||seen.has(entry.id))continue;
   const game=(entry.type==='mobile'?mobile.games:ports.games).find(g=>g.id===entry.id);if(!game)continue;
   seen.add(entry.id);arrivals.push({entry,game});
  }
  if(!arrivals.length)return;
  const make=(tag,cls,value)=>{const node=document.createElement(tag);if(cls)node.className=cls;if(value)node.textContent=value;return node;};
  const panel=make('section','new-games-panel');panel.setAttribute('aria-labelledby','new-games-title');
  const head=make('div','new-games-heading'),intro=make('div');
  intro.append(make('p','eyebrow','PATCH NOTES / NEW GAMES'));
  const title=make('h2','','Just added. Ready to play.');title.id='new-games-title';intro.append(title);
  const count=make('span','new-games-count',arrivals.length+' new arrivals');head.append(intro,count);
  const grid=make('div','new-games-grid');
  for(const {entry,game} of arrivals){
   const card=make('article','new-game-card');
   if(game.image){const image=make('img');image.src=new URL(game.image,document.baseURI);image.alt='';image.width=image.height=48;card.append(image);}else card.append(make('span','new-game-symbol','Ⅱ'));
   const info=make('div','new-game-info');info.append(make('span','new-game-badge','NEW'),make('h3','',game.name),make('p','',entry.type==='mobile'?'Mobile game':'Your game files required'));
   const button=make('button','new-game-launch','Launch now ↗');button.type='button';button.setAttribute('aria-label','Launch '+game.name+' now');
   button.onclick=()=>{if(entry.type==='mobile'){setConnection('scramjet');startBrowser(game.url);}else{openGame({id:game.id,name:game.name,cat:'Webported Games',size:'big',embed:new URL(game.url,document.baseURI).href,external:!game.local,help:game.requirements||'Click inside the game for controls.'},true);}};
   card.append(info,button);grid.append(card);
  }
  panel.append(head,grid);const anchor=home.querySelector('.home-essentials');if(anchor)anchor.before(panel);else home.prepend(panel);
 }catch(error){console.warn('New games panel unavailable.');}
}
document.addEventListener('pixel-interface-ready',initialize,{once:true});if(!document.body.classList.contains('arcade-booting'))initialize();
})();
