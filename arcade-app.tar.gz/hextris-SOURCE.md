Source: https://github.com/Hextris/hextris
License: GPL-3.0.
Complete source, local modifications and licence are provided in hextris-source.tar.gz and hextris-LICENSE.txt.
