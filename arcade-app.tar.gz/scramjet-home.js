// Scramjet destinations use the existing authenticated Pixel browser connection.
(()=>{
 function initialize(){
  const standby=document.querySelector('#browser-standby');if(!standby||standby.dataset.scramjetHome)return;standby.dataset.scramjetHome='1';standby.classList.add('scramjet-dashboard');
  standby.querySelector('.eyebrow').textContent='SCRAMJET / YOUR WEB SPACE';standby.querySelector('h2').textContent='Where do you want to go?';standby.querySelector('p').textContent='Search above, open a favourite, or launch a mobile game below.';
  const shortcuts=document.querySelector('#browser-start-apps');shortcuts.setAttribute('aria-label','Scramjet quick links');
  for(const b of shortcuts.querySelectorAll('button'))b.setAttribute('aria-label','Browse '+b.textContent.trim()+' with Scramjet');
  const section=document.createElement('section');section.className='cloudmoon-section';section.setAttribute('aria-labelledby','cloudmoon-heading');
  const heading=document.createElement('h2');heading.id='cloudmoon-heading';heading.textContent='Emulated mobile games';
  const note=document.createElement('p');note.textContent='Play mobile favourites in your browser. Availability depends on your connection.';
  const grid=document.createElement('div');grid.className='cloudmoon-grid';section.append(heading,note,grid);standby.append(section);
  fetch(new URL('cloudmoon.json?v=1',document.baseURI),{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('Mobile games could not load.');return r.json();}).then(data=>{
   for(const game of data.games){const u=new URL(game.url);if(u.origin!=='https://web.cloudmoonapp.com'||!u.pathname.startsWith('/game/'))continue;
    const card=document.createElement('article');card.className='cloudmoon-card';const image=document.createElement('img');image.src=new URL(game.image,document.baseURI).href;image.alt='';image.loading='lazy';image.width=image.height=88;image.onerror=()=>{image.hidden=true;};const title=document.createElement('h3');title.textContent=game.name;const play=document.createElement('button');play.type='button';play.textContent='Play';play.setAttribute('aria-label','Play '+game.name);play.onclick=()=>{setConnection('scramjet');startBrowser(u.href);};card.append(image,title,play);grid.append(card);
   }
  }).catch(error=>{grid.textContent=error.message;});
 }
 document.addEventListener('pixel-interface-ready',initialize,{once:true});if(!document.body.classList.contains('arcade-booting'))initialize();
 window.addEventListener('message',event=>{if(event.origin!==location.origin||event.data?.type!=='pixel:scramjet:status')return;for(const [id,frame]of browserFrames){if(frame.contentWindow!==event.source)continue;const tab=browserSession.tabs.find(t=>t.id===id);if(!tab)return;clearTimeout(browserTimers.get(id));browserTimers.delete(id);tab.status=String(event.data.message||'').slice(0,500);if(browserSession.active===id)document.querySelector('#browser-status').textContent=tab.status;}});
})();
