// Same-origin transport. Authentication stays in a Secure, HttpOnly cookie.
(()=>{
 async function request(path,options={}){
  if(!path.startsWith('/api/'))throw Error('Invalid service path.');
  const headers=new Headers(options.headers||{});headers.set('X-Pixel-Client','pixel-arcade');
  let response;try{response=await fetch('/arcade-api/'+path.slice(5),{...options,headers,credentials:'same-origin'});}catch{throw Error('Pixel services could not be reached. Check your connection and retry.');}
  const data=await response.json().catch(()=>({error:'Pixel services returned an unexpected response.'}));
  if(!response.ok)throw Object.assign(Error(data.error||'Could not complete that request.'),{status:response.status});
  if(path==='/api/auth/logout'||(path==='/api/auth/recovery'&&data.signedOut))document.dispatchEvent(new CustomEvent('pixel-session-changed'));
  return data;
 }
 window.pixelApi={request};
})();
